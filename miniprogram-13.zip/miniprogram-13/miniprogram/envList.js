const envList = [{"envId":"cloud1-1g74pkis98e03d8d","alias":"cloud1"}]
const isMac = true
module.exports = {
    envList,
    isMac
}